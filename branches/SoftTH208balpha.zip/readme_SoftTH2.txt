---------------------------------------------------------
               �:  SoftTH v2.08b alpha  :�
           x86 build - for 32bit programs only
---------------------------------------------------------

* alpha test version - many features are still missing *

Visit http://www.kegetys.net/forum/index.php?board=1.0
for feedback/more information.

SoftTH allows spanning Direct3D 9 games to multiple display
outputs. Any number of outputs is supported in any kind of
configuration (landscape, portrait, different resolutions).

Only one video card does all the rendering work so secondary
card(s) to which extra monitors are attached can be a low end,
only Direct3D support is required.

SoftTH 2 requires Windows 7 with WDDM drivers to work.

Make sure you have the latest DirectX 9 runtime installed
(http://www.microsoft.com/download/en/details.aspx?id=35)

To use, place the d3d9.dll into the game executable directory
(this is usually the directory where the game main EXE is located.
Sometimes the correct path can be a sub directory with DLL files
such as "bin"). When the game is run for the first time and
SoftTH is loaded a default configuration will be created. The
default config will span all detected monitors in the configuration
they are set in Windows desktop. You can open the created
config.SoftTHconfig file with a text editor to change settings.

The renderResolution that is set in the config will be added to
the list of video modes when the game enumerates them. When
the game uses this resolution (you will need to select it for
the game to use, or set it into a configuration file manually)
the game will render to a buffer that is the size of renderResolution,
and areas of this buffer will be copied to the outputs set 
in the config. The 'sourceRect' setting for each output head
defines the rectangle from which the data for the output is copied.
The format is:
x-coordinate,y-coordinate,width,height

For example:

renderResolution=2000x1000
...
[head_primary]
sourceRect=1000,0,1000,1000
...
[head_1]
devID=1
sourceRect=0,0,1000,1000

Here a screen buffer of 2000x1000 pixels is defined. The
primary monitor will display the right side 1000x1000 area
of this buffer and the secondary monitor will display the
left side.

Current config settings include:

[main] section:

nonlocalFormat: Format used for non-local heads (monitors which
are not attached to the primary video card). Possible options are:
RGB32  - 32bit RGB-8888 mode
RGB16  - 16bit RGB-565 mode
RGB16D - 16bit RGB-565 mode with dithering for smoother appearance
The 16bit modes offer better performance when using non-local heads
by reducing the amount of data copied in half.

keepComposition: If set to 1, keeps Windows WDDM desktop composition
enabled. Disabling the composition usually improves frame rate.

smoothing: If set to 1, smooths the framerate by disallowing excess
render-ahead. Setting of 0 can give higher overall FPS but can result
in FPS "spiking" resulting in stuttering gameplay.

debugD3D: Enables Direct3D debug runtime and captures the output to
log. Causes a significant performance decrease.

zClear: If set to 1, a depth-buffer trick is used to avoid rendering
to any areas of the renderResolution buffer which are not covered
by any display output. This can significantly improve performance
if large areas of the render buffer are "unused". However it can
also cause problems if the depth buffer is detected wrong or if the
game uses post-processing effects to distort the rendered view.

vsync: 1 = enable vsync, 0 = disable vsync.
tripleBuffer: 1 = enable triple buffering. Recommended with vsync
enabled, but causes an extra frame of latency to the rendering.

screenshotFormat: Format of screenshots saved with printscreen.
Possible values: jpg, png, bmp

dllPathD3D9: Path to D3D9.DLL DLL to use. Set to 'auto' to use
Windows sytem32 path. If you use other "proxy" DLLs then you can
point this to the path of the other DLL.


[overrides] section:

forceResolution: If set to 1, device is forced to be created in
the resolution set in renderResolution. This can be used to force
a game into the wanted mode if the mode is not selectable in-game.
Doing this often causes problems with the game as it will not be aware
of the mode change.

antialiasing: If set to >0, forces antialiasing to set value. If
the game does not support selecting AA then using this option is
preferred over a display driver forced setting.

processAffinity: If set to 1, forces the process affinity to all
detected CPU cores. SoftTH takes use of multithreading, and if the
game forces the affinity to just one core/cpu then performance will
not be optimal. However, forced affinity can cause problems with
the game if it does not properly handle multithreading.

FOVForceHorizontal & FOVForceVertical: Attempts to force the FOV
for games which "strecth" the output. Only works with games that
use the fixed-function pipeline (no vertex shaders).


[debug] section:

compatibleIB: If set to 1 index buffer manage-emulation is disabled
and dynamic indexbuffers are used instead. This can fix incompatiblities
like missing geometry or crashes but usually decreases performance.

compatibleTex: If set to 1 texture manage-emulation is disabled and
dynamic textures are used instead. This can fix incompatiblities
like missing textures or crashes but usually decreases performance.

compatibleVB: If set to 1 index buffer manage-emulation is disabled
and dynamic indexbuffers are used instead. This can fix incompatiblities
like missing geometry or crashes but usually decreases performance.

enableVBQuirk: Enable "quirk-mode" for vertex buffers which allows
the game to lock a too large area of a vertex buffer. This was
required by DCS A-10C beta but the bug has been fixed in later versions.


[head_primary] section:

This section defines the primary head which is attached to the primary
video card and is always present.

sourceRect: Position and width,height of the source rectangle for the
primary monitor. For example (3840,0,1920,1200)

screenMode: Screen resolution to which the primary monitor is set.
This does not need to match the width and height of the source rectangle.


[head_X] section:

These sections define an additioal output head. There can be any
number of outputs. The numbers must be sequential starting from 1
(ie. for three additional outputs you need head_1, head_2 and head_4
resulting in four total outputs with the head_primary).

devID: Direct3D 9 device ID for this head. ID 0 is always the
primary head defined in head_primary, the rest are indexes set
by windows starting from 1.

sourceRect: Source rectangle for this output, same as for head_primary

transportResolution: Transport resolution used for this head. This
setting can be used to improve performance for monitors that are
not attached to the primary video card. It can be of any size between
8x8 and the width and height of the source rectangle.

transportMethod: Transport method used for this head. Possible options:
auto     - Autodetect output method
local    - Use shared surfaces
nonlocal    - Copy data through system RAM (32bit)
nonlocal16  - Copy data through system RAM (16bit)
nonlocal16d - Copy data through system RAM (16bit + dithering)

noSync: Do not wait for this head to be presented. For a very slow
output device this allows the game to render at a high frame rate while
the output is updated at a lower rate.

fpsLimit: Limit the rate at which this head is updated. Can be used for
example for USB displays used as flightsim gauges/instruments to reduce
overhead from their updating.


SoftTH creates a log file to your "My Documents/SoftTH" directory.
Screenshots are also saved there.

Currently supported hotkeys are:
- Print screen: Save screenshot in TGA format
- App key + E: Toggle smoothing on/ogg
- App key + G: Toggle frame time graph on/off
- App key + B: Debug bars on/off
- App key + W: Toggle left/right monitor data copy
- App key + S: Toggle squashing, draws whole frame to middle
  monitor only, helpful for using UI with games that stretch
  the UI to all three monitors
- App key + F4: Force application quit

(App key is the application key next to the right windows key)


---------------------------------------------------------
  credits
---------------------------------------------------------

SoftTH is made by Kegetys, http://www.kegetys.net
Uses the diStorm3 binary stream disassembler

Special thanks to everyone who has donated to support
the project

---------------------------------------------------------
  known bugs
---------------------------------------------------------

- SoftTH HUD text is sometimes incorrectly placed
- Flight Simulator X: Mouse input is not working correctly
- Any scaling on the output copying is low quality
- Task switching ("alt tabbing") usually does not work

---------------------------------------------------------
  changelog
---------------------------------------------------------

* 2.08 alpha
- GetContainer support for textures (TES Skyrim)
- Improved index- and vertexbuffer emulation
- Quirk support for invalid VB locks disabled by default
- Fix discard flag use with emulated index buffers (DCS A-10C)
- Config settings to disable various manage-emulation modes

* 2.07 alpha
- Fixed GetTexture behaviour (NFS Shift 2, C.A.R.S, Rfactor, ...)
- Workaround for D3D9Ex non-primary swapchain backbuffer
  rendering (Falcon 4 BMS)
- Device reset to windowed mode is no longer incorrectly
  used as SoftTH mode (Falcon 4 BMS)
  
* 2.06 alpha
- fpsLimit setting for non-primary heads
- Managed volume texture fixes (Rise of Flight)
- Fixed memory leak with GetSwapChain
- Fixed memory leak with GetSurfaceLevel
- SoftTH no longer incorrectly activates on windowed mode device

* 2.05 alpha
- Improved local head performance for AMD cards
- Fixed RGB16D nonlocal mode on AMD cards
- Slightly improved nonlocal performance for Nvidia 
  cards (Restored to v2.02 level)
- Reduced CPU use when waiting for gpu synchronization
- Framerate smoothing is always disabled if all heads
  are local
- Fixed potential crash with hooks

* 2.04 alpha
 - Improved mouse cursor hooking (World of Warcraft)
 - Fixed QueryInterface behaviour for non-D39Ex device
   (Rise of Flight, Netkar Pro, Mount & Blade, ...)
 - Fixed volume surface locking behaviour
 
* 2.03 alpha
 - Fixed nonlocal performance on ATI cards
 - Fixed crash with steam overlay introduced in v2.02
   (Left 4 Dead 2, Team Fortress 2, ...)
 - Added support for Direct3D 9Ex games (Fallout New Vegas)
 
* 2.02 alpha
 - Fixed non-managed volume texture handling
 - Improved performance with partial texture locks
 - Quirk support for invalid vertex buffer locks (DCS A10C Beta)
 - x64 support

* 2.01 pre-alpha
 - Improved manage texture emulation (Richard Burns Rally, 
   X3 Terran Conflict, Bioshock 2, ...)
 - Volume texture manage-emulation fixes (Portal, Left 4 Dead 2)
 - Various COM interface compatibility fixes
 - GetCursorInfo hook (ArmA2 v1.07)
 - TrackMouseEvent messages handling (Dragon Age: Origins)

* 2.0 pre-alpha
 - Re-written almost completely from scratch
 - Supports any number of outputs in any configuration
 - New configuration method


* 1.09beta (rc1)
 - Win32 monitorInfo hooks (Flight Simulator X)
 - Nonmultisampled lockable backbuffer support (UT 2004)
 - Fixed default depthbuffer render state with disabled autodepthbuffer
   (Race Driver Grid, Midnight Club 2 ...)
 - sideExtraWidth autodetection now uses desktop resolution setting
   of secondary monitors instead of secondaryWidth/Height resolution
 - Experimental CUDA fame copy support for Nvidia cards
   (RGB32CUDA secondaryFormat setting)
 - Forced SetRenderTarget override if application attempts to set
   real backbuffer instead of SoftTH one (GTA 4)
 - secondaryFormat setting validation  
 - forceAffinity setting to force process affinity to all processors
   (DCS Black Shark, rFactor, GTR2...)
 - Various selectable frame upload methods for non-multihead heads
   (uploadMethod config setting): Win32 blit, Direct3D, CUDA
 - Screenshots are now saved to user 'my documents' directory
 - Fixed device reference counter when using lens correction
 - Fixed excess present thread initialization on device reset
 - Some Vista WDDM multihead related crash workaround attempts
 - OSD color/texturing fixes
  
* 1.08beta
 - Improved free device reference counting for better compatibility
 - Some minor changes/fixes

* 1.08beta (rc3)
 - Fixed sideExtraWidth auto setting (result was always zero)
 - Reference rasterizer support for cards without D3D acceleration
 - Fixed possible multithreading issue with secondary screen blit
 - Thread priority adjustments for smoother fps
 - Some mouse button status fixes

* 1.08beta (rc2)
 - Fixed performance with RGB16D mode
 - Fixed possible crash with D3D9 GetDepthStencilSurface
 - Window rect scaling
 - Various minor compatibility fixes

* 1.08beta (rc1)
 - Improved Autosquash detection
 - Removed cylindrical correction setting
 - Added lens correction postprocessing effect
 - Depthstencil created by SoftTH now uses discard flag
   if application originally requested it
 - Pixel shader dithering in RGB16 mode for cards that
   do not support dithering (ie. GeForce 80000 series)
 - Reduced video memory use and improved compatibility
   for antialiasing
 - Changed to global mouse hook for better compatiblity
 - Automatic screenmode & sideExtraWidth detection
 - New faster, simplier, multithread safe win32 api hooks

* 1.07beta
 - Autodetection for various settings such as secondary
   resolution, device ID, etc. (default)
 - Support for D3D9 swap chains (for Call of Duty 2, 
   Company of Heroes...)
 - Persistent win32api hooks for more reliable hooking
 - Uses debug access to write memory if regular access
   fails (requires admin/debug privileges from user)
 - Some default settings adjusted for better compatibility
 - Improved device release detection & handling
 - Mouse compatibility fixes
 - Config file settings separated for OpenGL & Direct3D
 - Global config file support in user home directory
 - Autosquash option for automatic squashing when no 3D
   elements drawn
 - Forced multihead use (useMultihead=2) for games that
   do not immediately initialize the device with the
   triplehead resolution (Such as Test Drive Unlimited)
 - Misc fixes & improvements
 
* 1.06beta
 - Fixed crash when no depth buffer requested by application
   (for Nascar Racing 2003)
 - Fixed log output path when app changes current directory
 - Fixed config read path when app changes current directory
 - Using D3DCREATE_FPU_PRESERVE flag in secondary devices if
   requested for primary device (for Bioshock)
 - Added doScaleFromLeftScreen setting to scale mouse
   coordinates from left screen to full width (for netKar Pro)
 - Misc minor fixes and improvements

* 1.05beta
 - Fixed task switching crash in 1.04
 - Fixed refresh rate check
 - Added support for D3D9 multihead acceleration if primary
   device supports it (dual head cards)
 - Added mouseXoffset hook setting to fix misplaced mouse
   cursor position (for Armed Assault)
 - Fixed forceHorizontalFOV when using border setting
 - Added sideExtraWidth setting
 - Added cylindrical correction setting
 - Added SoftTH identifier to primary device description
 - Improved DLL load handling (for Stalker Shadow of Chernobyl)

* 1.04beta
 - Improved keyboard shortcut handling
 - Improved screenshot handling
 - Improved anti-aliasing support (Game-requested setting
   is detected by SoftTH and used automatically)
 - Experimental Win32 API hooks
 - Added hook option for scaling getCursorPos coordinates
   (For Test Drive Unlimited)
 - Added hotkey for 'squashing' output to middle monitor
 - Improved settings validation (Supported resolution check)
 - Fixed resolution returned by CreateDevice for improved
   border setting compatibility (ISI racing sims)

* 1.03beta
 - Improved performance and compatibility
 - Improved mouse compatibility
 - Added sleepBeforeRead config setting
 - Added hotkeys and setting to disable them
 - Added setting to change left/right monitor copy order

* 1.01beta
 - Some D3D9 compatibility fixes
 - Forced resolution override
 - Option to hide non-default devices
 - Set multithreading flag for D3D device
 - Option to disable multithreading flag

* 1.0beta
 - first version
 
---------------------------------------------------------
  license & disclaimer
---------------------------------------------------------

You are permitted to install and use this software for 
personal entertainment purposes only. Any commercial,
military or educational use is strictly forbidden without
permission from the author. 

You are free to distribute this software as you wish, as 
long as it is kept 100% free of charge, it is not modified 
in any way and this readme file is distributed with it.

The author takes no responsibility for any damages this 
program may cause, use at your own risk.

---------------------------------------------------------